// Vercel serverless function for API routes
// This exports the Express app for Vercel serverless functions
const app = require('../server/index.js');

module.exports = app;
